﻿import zipfile, re
docx_path = "D:/\xe6\x89\xac\xe5\xb7\x9e\xe8\x81\x8c\xe4\xb8\x9a\xe8\xbd\xaf\xe4\xbb\xb6\xe5\x8a\x9f\xe8\x83\xbd\xe9\x9c\x80\xe6\xb1\x82.docx"
with zipfile.ZipFile(docx_path) as z:
    with z.open("word/document.xml") as f:
        xml = f.read().decode("utf-8")
text = re.sub(r"<[^>]+>", " ", xml)
text = re.sub(r"\s+", " ", text).strip()
print(text[:12000])

# 🚀 Sealos 云部署指南 — 扬州培训平台

## 方案概述

本指南通过 Sealos DevBox 完成代码上传、镜像构建和部署，全程无需本地 Docker 和 GitHub。

**你将获得**：`https://xxx.sealos.run` 免费域名 + HTTPS + 数据持久化

---

## 第一步：注册 Sealos 账号

1. 打开浏览器访问 **https://cloud.sealos.run**
2. 点击「注册」，支持微信扫码 / 手机号注册
3. 注册后自动赠送 **5 元免费额度**（够演示用很久）

---

## 第二步：创建 DevBox（云端开发环境）

DevBox 是一个云端的 VS Code，自带 Docker + Node.js + 网络代理。

1. 登录后左侧菜单点击 **「DevBox」**
2. 点击 **「新建 DevBox」**
3. 配置如下：
   | 参数 | 值 |
   |------|-----|
   | 名称 | `yz-training-builder` |
   | 镜像 | `Node.js` 或 `Ubuntu 22.04` |
   | CPU | 1 核 |
   | 内存 | 2 GB |
4. 点击创建，等待 1 分钟启动
5. 点击 **「打开」** 进入在线 VS Code

---

## 第三步：上传项目代码

在 DevBox 的终端中执行：

```bash
# 方式一：通过 GitHub 镜像克隆（如果 GitHub 直连不行就用镜像）
git clone https://ghproxy.net/https://github.com/ljjs1993s/yangzhou-training-platform.git
cd yangzhou-training-platform

# 如果上面的镜像也不行，手动创建项目目录并上传文件
# （在 DevBox 的 VS Code 中，直接把本地文件拖拽到文件浏览器即可）
```

---

## 第四步：构建 Docker 镜像

在 DevBox 终端中：

```bash
cd yangzhou-training-platform

# 构建镜像
docker build -t yz-training:latest .

# 验证镜像
docker images | grep yz-training
```

---

## 第五步：推送到 Sealos 内置镜像仓库

Sealos 自带免费的镜像仓库（无需额外注册）：

```bash
# 登录 Sealos 镜像仓库
docker login sealos.hub —username=你的手机号

# 打标签
docker tag yz-training:latest sealos.hub/你的用户名/yz-training:latest

# 推送
docker push sealos.hub/你的用户名/yz-training:latest
```

---

## 第六步：部署到 Sealos 应用管理

1. 回到 Sealos 控制台，左侧点击 **「应用管理」**
2. 点击 **「新建应用」**
3. 填写配置：

### 基础配置
| 参数 | 值 |
|------|-----|
| 应用名称 | `yz-training-platform` |
| 镜像地址 | `sealos.hub/你的用户名/yz-training:latest` |
| CPU | 0.5 核 |
| 内存 | 512 MB |

### 网络配置
| 参数 | 值 |
|------|-----|
| 容器端口 | `3001` |
| 外网访问 | ✅ 开启 |
| 域名 | 自动生成（如 `yz-training-xxx.sealos.run`） |

### 环境变量
| 变量名 | 值 |
|--------|-----|
| `DATA_DIR` | `/data` |
| `UPLOAD_DIR` | `/data/uploads` |

### 持久化存储
| 参数 | 值 |
|------|-----|
| 挂载路径 | `/data` |
| 存储大小 | 1 GB |

4. 点击 **「部署」**，等待 2-3 分钟

---

## 第七步：验证部署

部署完成后，Sealos 会显示公网访问地址。

1. 复制域名（格式：`https://yz-training-xxx.sealos.run`）
2. 浏览器打开，确认培训平台首页正常显示
3. 用测试账号登录验证：
   - 管理员：`admin / admin123`
   - 教师：`teacher / teacher123`
   - 学员：`student / student123`

---

## 🎉 双保险完成

| 方案 | 地址 | 说明 |
|------|------|------|
| 方案 A（已就绪） | `https://891d0a37ee2669.lhr.life` | localhost.run 隧道 |
| 方案 B（按本指南） | `https://xxx.sealos.run` | Sealos 云部署 |

---

## 📌 注意事项

1. **免费额度**：Sealos 赠送 5 元，按量计费。0.5核/512MB 配置约 ¥0.03/小时，够用一周以上
2. **数据安全**：因应用使用 JSON 文件存储（非数据库），持久卷 `/data` 会自动保存所有数据
3. **GitHub Actions**：仓库中已配置 `.github/workflows/docker-build.yml`，等 GitHub 恢复后会自动构建镜像到 ghcr.io
4. **重新部署**：修改代码后，在 DevBox 中重新 `docker build && docker push`，然后在应用管理中点击「重启」即可

---

## 🔧 故障排查

| 问题 | 解决方法 |
|------|----------|
| DevBox 中 `docker` 命令不存在 | 运行 `apt update && apt install -y docker.io` |
| 推送镜像 403 | 重新 `docker login sealos.hub` |
| 应用启动后 502 | 检查环境变量 `DATA_DIR=/data` 是否配置正确 |
| 数据丢失 | 确认持久卷挂载路径 `/data` 已配置 |
